const crypto = require('crypto');

// Garmin's provided example values
const method = 'POST';
const url = 'https://connectapi.garmin.com/oauth-service/oauth/access_token';
const consumerKey = 'cb60d7f5-4173-7bcd-ae02e5a52a6940ac';
const consumerSecret = '3LFNjTLbGk5QqWVoypl8S2wAYcSL586E285';
const tokenSecret = 'VP2ZGuciICb7Lu769KWOP0wNMxxoLUZdAbq'; // Token secret obtained during the request token step
const oauthToken = '760d85bd-b86e-4da6-b58b-ba57a542b23b';
const oauthVerifier = 'wvDJQmLSwY';
const oauthNonce = '2lRbgVyTAgh';
const oauthTimestamp = '1484913680';

// Constructing the signature base string
const parameterString = `oauth_consumer_key=${consumerKey}&oauth_nonce=${oauthNonce}&oauth_signature_method=HMAC-SHA1&oauth_timestamp=${oauthTimestamp}&oauth_token=${oauthToken}&oauth_verifier=${oauthVerifier}&oauth_version=1.0`;
const signatureBaseString = `${method}&${encodeURIComponent(url)}&${encodeURIComponent(parameterString)}`;

// Generating the signing key
const signingKey = `${encodeURIComponent(consumerSecret)}&${encodeURIComponent(tokenSecret)}`;

// Generating the signature
const signature = crypto.createHmac('sha1', signingKey).update(signatureBaseString).digest('base64');

console.log('Signature Base String:', signatureBaseString);
console.log('Generated Signature:', signature);